## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_restaurant_form
    - slot{"location": "bangalore"}
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"cuisine": "chinese"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant_form
    - slot{"budget": "less than 300"}
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "less than 300"}
    - utter_ask_send_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "location"}
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "california"}
    - slot{"location": "california"}
    - action_restaurant_form
    - slot{"location": "california"}
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - action_restaurant_form
    - slot{"cuisine": "mexican"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"location": null}
    - slot{"cuisine": "mexican"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - action_restaurant_form
    - slot{"location": "hyderabad"}
    - slot{"cuisine": "mexican"}
    - slot{"budget": "more than 700"}
    - utter_ask_send_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "washington"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "washington"}
    - action_restaurant_form
    - slot{"location": "washington"}
    - slot{"cuisine": "chinese"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"requested_slot": "location"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_restaurant_form
    - slot{"location": "delhi"}
    - slot{"location": "delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "more than 700"}
    - utter_ask_send_email
* send_email
    - utter_ask_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - action_restaurant_form
    - slot{"location": "mumbai"}
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_restaurant_form
    - slot{"cuisine": "american"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "300 - 700"}
    - slot{"budget": "300 - 700"}
    - action_restaurant_form
    - slot{"budget": "300 - 700"}
    - slot{"location": "mumbai"}
    - slot{"cuisine": "american"}
    - slot{"budget": "300 - 700"}
    - utter_ask_send_email
* affirm
    - utter_ask_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_restaurant_form
    - slot{"location": "bangalore"}
    - slot{"requested_slot": "cuisine"}
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"budget": "< 300"}
    - slot{"budget": "< 300"}
    - action_restaurant_form
    - slot{"budget": "< 300"}
    - slot{"requested_slot": "cuisine"}
* restaurant_search
    - action_restaurant_form
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"cuisine": "chinese"}
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "< 300"}
    - utter_ask_send_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "budget": "> 1000"}
    - slot{"budget": "> 1000"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"cuisine": "chinese"}
    - slot{"budget": "> 1000"}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - action_restaurant_form
    - slot{"location": "hyderabad"}
    - slot{"location": "hyderabad"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - action_restaurant_form
    - slot{"location": "hyderabad"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"location": "hyderabad"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "more than 700"}
    - utter_ask_send_email
* send_email
    - action_send_email_form
    - slot{"requested_slot": "email"}
* deny
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "california"}
    - slot{"location": "california"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_restaurant_form
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search
    - action_restaurant_form
    - slot{"budget": null}
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant_form
    - slot{"budget": "less than 300"}
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - utter_ask_send_email
* deny
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "washington"}
    - slot{"location": "washington"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "mumbai"}
    - slot{"location": "mumbai"}
    - action_restaurant_form
    - slot{"location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "less than 200"}
    - slot{"budget": "less than 200"}
    - action_restaurant_form
    - slot{"budget": null}
    - slot{"location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant_form
    - slot{"budget": "less than 300"}
    - slot{"location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - utter_ask_send_email
* send_email{"email": "asjd.com"}
    - slot{"email": "asjd.com"}
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "illinois"}
    - slot{"cuisine": "italian"}
    - slot{"location": "illinois"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "italian"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_restaurant_form
    - slot{"location": "delhi"}
    - slot{"cuisine": "italian"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "< 900"}
    - slot{"budget": "< 900"}
    - action_restaurant_form
    - slot{"budget": null}
    - slot{"location": "delhi"}
    - slot{"cuisine": "italian"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "300 - 700"}
    - slot{"budget": "300 - 700"}
    - action_restaurant_form
    - slot{"budget": "300 - 700"}
    - slot{"location": "delhi"}
    - slot{"cuisine": "italian"}
    - utter_ask_send_email
* send_email
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
* deny
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "bangalore", "budget": "between 300 to 700"}
    - slot{"budget": "between 300 to 700"}
    - slot{"cuisine": "american"}
    - slot{"location": "bangalore"}
    - action_restaurant_form
    - slot{"location": "bangalore"}
    - slot{"cuisine": "american"}
    - slot{"budget": "between 300 to 700"}
    - utter_ask_send_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* restaurant_search
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": null}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - action_restaurant_form
    - slot{"location": "pune"}
    - slot{"cuisine": null}
    - slot{"budget": null}
    - slot{"requested_slot": "cuisine"}
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_restaurant_form
    - slot{"cuisine": "north indian"}
    - slot{"location": "pune"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "more than 700"}
    - slot{"budget": "more than 700"}
    - action_restaurant_form
    - slot{"budget": "more than 700"}
    - slot{"location": "pune"}
    - slot{"cuisine": "north indian"}
    - utter_ask_send_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "jaipur"}
    - slot{"location": "jaipur"}
    - action_restaurant_form
    - slot{"location": "jaipur"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "300 - 400"}
    - slot{"budget": "300 - 400"}
    - action_restaurant_form
    - slot{"budget": null}
    - slot{"location": "jaipur"}
    - slot{"cuisine": "chinese"}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "300 - 700"}
    - slot{"budget": "300 - 700"}
    - action_restaurant_form
    - slot{"budget": "300 - 700"}
    - slot{"location": "jaipur"}
    - slot{"cuisine": "chinese"}
    - utter_ask_send_email
* deny
    - utter_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "hyderabad", "budget": "300 - 700"}
    - slot{"budget": "300 - 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "hyderabad"}
    - action_restaurant_form
    - slot{"location": "hyderabad"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": "300 - 700"}
    - utter_ask_send_email
* send_email
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "london"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "london"}
    - action_restaurant_form
    - slot{"location": null}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "location"}
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_restaurant_form
    - slot{"location": "Bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
    - utter_ask_send_email
* send_email
    - utter_ask_email
* send_email{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "kolkata"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "kolkata"}
    - action_restaurant_form
    - slot{"location": "kolkata"}
    - slot{"cuisine": "chinese"}
    - slot{"budget": null}
    - slot{"requested_slot": "budget"}
* restaurant_search{"budget": "less than 300"}
    - slot{"budget": "less than 300"}
    - action_restaurant_form
    - slot{"budget": "less than 300"}
    - slot{"location": "kolkata"}
    - slot{"cuisine": "chinese"}
    - utter_ask_send_email
* send_email
    - action_send_email_form
    - slot{"email": null}
    - slot{"requested_slot": "email"}
* affirm{"email": "raviseh@gmail.com"}
    - slot{"email": "raviseh@gmail.com"}
    - action_send_email_form
    - slot{"email": "raviseh@gmail.com"}
    - utter_send_goodbye
    - action_restart

